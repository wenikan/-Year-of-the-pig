console.log('\x1b[35m%s\x1b[0m', ' _____               _____ _   \r\n|_   _|             |_   _| |  \r\n  | |_   _ _ __   ___ | | | |_ \r\n  | | | | | \'_ \\ \/ _ \\| | | __|\r\n  | | |_| | |_) |  __\/| |_| |_ \r\n  \\_\/\\__, | .__\/ \\___\\___\/ \\__|\r\n      __\/ | |                  \r\n     |___\/|_|   \n');
console.log('Thanks for using TypeIt! If you\'re using TypeIt commercially, please purchase a license at https://typeitjs.com.\n');

